# AI agento panaudojimas

AI agentas buvo naudotas straipsnio analizei, eksperimento atkūrimo plano sudarymui, programinio kodo parengimui, vietiniam eksperimentų vykdymui, rezultatų tikrinimui ir ataskaitos formavimui.

Svarbiausi AI agento atlikti veiksmai:

1. Palyginta straipsnyje aprašyta metodika su viešo UCI rinkinio struktūra.
2. Aptiktas atkuriamumui svarbus neatitikimas: straipsnyje vienos valandos duomenims nurodyti 4 380 įrašų, nors 365 dienos turi 8 760 valandų.
3. Parengtas kodas trims LSTM architektūroms ir penkiems slankiojo lango dydžiams.
4. Eksperimentai paleisti vietinėje Python aplinkoje.
5. Rezultatai palyginti su straipsnyje pateiktomis reikšmėmis ir patikrinti pagal bazinę pastovumo prognozę.

Galutinės išvados grindžiamos programos išsaugotais CSV ir JSON rezultatais, o ne vien AI agento tekstiniu vertinimu.
