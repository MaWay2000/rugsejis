# ND2 Energijos suvartojimo prognozavimas

Studentas: Mantas Matusevičius  
Grupė: DISfm-26

Darbas atkartoja 2023 m. straipsnio „Energy Usage Forecasting Model Based on Long Short-Term Memory LSTM and eXplainable Artificial Intelligence XAI“ eksperimentus su UCI „Steel Industry Energy Consumption“ duomenimis.

## Paleidimas

Windows PowerShell aplinkoje:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run_experiments.py
```

Programa:

- paruošia 35 040 pradinių matavimų;
- suformuoja 4 380 dviejų valandų stebėjimų;
- chronologiškai atskiria sausio-spalio mokymo ir lapkričio-gruodžio testavimo duomenis;
- išbando vieno sluoksnio LSTM, dviejų sluoksnių LSTM ir Bi-LSTM;
- kiekvienai architektūrai išbando 1, 4, 8, 12 ir 16 stebėjimų langus;
- apskaičiuoja RMSE, MAE, R2 ir WIA;
- palygina rezultatus su straipsniu;
- sukuria grafikus, modelius ir SHAP požymių svarbos analizę.

Straipsnyje vienos valandos duomenims nurodyti 4 380 įrašų, nors vieneri metai turi 8 760 valandų. Šiame atkūrime naudojamas dviejų valandų agregavimas, nes tik jis pateikia straipsnyje nurodytą įrašų skaičių. Šis neatitikimas aptariamas ataskaitoje.

## Šaltiniai

- Maarif, M. R. ir kt. Energy Usage Forecasting Model Based on Long Short-Term Memory LSTM and eXplainable Artificial Intelligence XAI. Information, 2023, 14(5), 265. https://doi.org/10.3390/info14050265
- UCI Steel Industry Energy Consumption. https://doi.org/10.24432/C52G8C
