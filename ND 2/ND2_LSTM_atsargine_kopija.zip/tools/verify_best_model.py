"""Reload the saved best model and verify its stored metrics without retraining."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import pandas as pd
from tensorflow import keras

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import run_experiments as exp


def main() -> None:
    summary_path = ROOT / "results" / "santrauka.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    best = summary["best_model"]
    window = int(best["window"])

    data = exp.load_and_prepare_data()
    _, test, _, test_scaled, _, y_scaler_fresh = exp.split_and_scale(data)
    y_scaler = joblib.load(ROOT / "results" / "models" / "target_scaler.joblib")
    model = keras.models.load_model(ROOT / "results" / "models" / "geriausias_modelis.keras")
    x_test, y_test = exp.sequences(test_scaled, window)
    prediction = model.predict(x_test, verbose=0).ravel()
    metrics = exp.evaluate(y_test, prediction, y_scaler)

    if abs(metrics["rmse_scaled"] - best["rmse_scaled"]) > 1e-7:
        raise AssertionError("Reloaded model metrics differ from saved summary")
    if abs(y_scaler.data_min_[0] - y_scaler_fresh.data_min_[0]) > 1e-12:
        raise AssertionError("Saved and reconstructed target scalers differ")

    actual = y_scaler.inverse_transform(y_test.reshape(-1, 1)).ravel()
    predicted = y_scaler.inverse_transform(prediction.reshape(-1, 1)).ravel()
    index = test.index[window:]
    pd.DataFrame(
        {
            "date": index,
            "actual_kwh": actual,
            "predicted_kwh": predicted,
            "error_kwh": predicted - actual,
        }
    ).to_csv(ROOT / "results" / "geriausio_modelio_prognozes.csv", index=False)
    exp.plot_predictions(index, actual, predicted, best["architecture"])
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
