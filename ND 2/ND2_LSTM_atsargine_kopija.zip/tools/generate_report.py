"""Generate the final ND2 Word report from saved experiment outputs."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
OUT = ROOT / "report" / "ND2_Mantas_Matusevicius_DISfm-26.docx"

NAVY = "214B72"
PALE_BLUE = "EAF2F8"
LIGHT_GRAY = "D9D9D9"
TEXT = RGBColor(0, 0, 0)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=100, start=110, bottom=100, end=110) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_cell_border(cell, color=LIGHT_GRAY, size="6") -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:color"), color)


def style_table(table, header=True, numeric_cols: set[int] | None = None) -> None:
    numeric_cols = numeric_cols or set()
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for r_idx, row in enumerate(table.rows):
        for c_idx, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_margins(cell)
            set_cell_border(cell)
            if header and r_idx == 0:
                set_cell_shading(cell, NAVY)
            elif r_idx % 2 == 0:
                set_cell_shading(cell, PALE_BLUE)
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = 1.0
                paragraph.alignment = (
                    WD_ALIGN_PARAGRAPH.CENTER if c_idx in numeric_cols or (header and r_idx == 0)
                    else WD_ALIGN_PARAGRAPH.LEFT
                )
                for run in paragraph.runs:
                    run.font.name = "Aptos"
                    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Aptos")
                    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Aptos")
                    run.font.size = Pt(9)
                    if header and r_idx == 0:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(255, 255, 255)


def add_caption(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(8)
    run = p.add_run(text)
    run.bold = True
    run.font.size = Pt(9)


def add_figure(doc: Document, path: Path, caption: str, width=6.65) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_after = Pt(0)
    p.add_run().add_picture(str(path), width=Inches(width))
    add_caption(doc, caption)


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    p = doc.add_heading(text, level=level)
    p.paragraph_format.keep_with_next = True


def add_body(doc: Document, text: str) -> None:
    p = doc.add_paragraph(text)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.first_line_indent = Cm(0.7)


def add_bullet(doc: Document, text: str) -> None:
    p = doc.add_paragraph(text, style="List Bullet")
    p.paragraph_format.space_after = Pt(3)


def pct(value: float) -> str:
    return f"{value:.4f}".replace(".", ",")


def build_report() -> None:
    summary = json.loads((RESULTS / "santrauka.json").read_text(encoding="utf-8"))
    all_results = pd.read_csv(RESULTS / "visi_bandymu_rezultatai.csv")
    comparison = pd.read_csv(RESULTS / "palyginimas_su_straipsniu.csv")
    best = summary["best_model"]

    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Aptos"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Aptos")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos")
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = TEXT
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.12

    title_style = styles["Title"]
    title_style.font.name = "Aptos Display"
    title_style._element.rPr.rFonts.set(qn("w:ascii"), "Aptos Display")
    title_style._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos Display")
    title_style.font.size = Pt(25)
    title_style.font.bold = True
    title_style.font.color.rgb = TEXT
    title_ppr = title_style._element.get_or_add_pPr()
    title_border = title_ppr.find(qn("w:pBdr"))
    if title_border is not None:
        title_ppr.remove(title_border)

    for name, size in (("Heading 1", 16), ("Heading 2", 12.5)):
        style = styles[name]
        style.font.name = "Aptos Display"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Aptos Display")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Aptos Display")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = TEXT
        style.paragraph_format.space_before = Pt(10)
        style.paragraph_format.space_after = Pt(5)

    # Title page
    p = doc.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(95)
    p.add_run("Energijos suvartojimo prognozavimas naudojant LSTM")
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p2.paragraph_format.space_before = Pt(18)
    r = p2.add_run("Mokslinio straipsnio eksperimentų atkūrimas")
    r.font.size = Pt(15)
    r.bold = True
    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.paragraph_format.space_before = Pt(74)
    p3.add_run("Studentas Mantas Matusevičius\n").bold = True
    p3.add_run("Grupė DISfm-26")
    p4 = doc.add_paragraph()
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p4.paragraph_format.space_before = Pt(70)
    p4.add_run("Namų darbas Nr 2").bold = True
    doc.add_page_break()

    add_heading(doc, "Darbo santrauka")
    add_body(
        doc,
        "Darbe atkartoti Maarif ir bendraautorių energijos suvartojimo prognozavimo eksperimentai. "
        "Vietinėje Python aplinkoje išbandytos trys neuroninių tinklų architektūros ir penki slankiojo "
        "lango dydžiai. Geriausią rezultatą pasiekė vieno sluoksnio LSTM su 12 stebėjimų langu: "
        f"normalizuotas RMSE {pct(best['rmse_scaled'])}, MAE {pct(best['mae_scaled'])}, "
        f"R2 {pct(best['r2_scaled'])} ir WIA {pct(best['wia_scaled'])}. Modelis gerokai aplenkė "
        "pastovumo bazinę prognozę ir atkūrė straipsnyje aprašytą ryšį tarp ilgesnio lango ir mažesnės paklaidos."
    )

    add_heading(doc, "1 Pasirinktas straipsnis")
    add_body(
        doc,
        "Pasirinktas atvirosios prieigos straipsnis M R Maarif, A R Saleh, M Habibi, N L Fitriyani ir "
        "M Syafrudin Energy Usage Forecasting Model Based on Long Short Term Memory LSTM and "
        "eXplainable Artificial Intelligence XAI. Jis paskelbtas žurnale Information, 14 tomo 5 numeryje, "
        "straipsnio numeris 265, DOI 10.3390/info14050265. Autoriai prognozavo plieno gamyklos energijos "
        "suvartojimą, palygino vieno sluoksnio LSTM, dviejų sluoksnių LSTM ir dvikryptį LSTM bei modelį "
        "aiškino SHAP metodu."
    )
    add_body(
        doc,
        "Straipsnio eksperimentų pasirinkimas skiriasi nuo ND1 darbo. ND1 buvo sprendžiama vaizdų "
        "klasifikavimo užduotis su SVM, o šiame darbe sprendžiama daugiamatės laiko eilutės regresijos ir "
        "prognozavimo užduotis su pasikartojančiais neuroniniais tinklais."
    )

    add_heading(doc, "2 Duomenys ir paruošimas")
    add_body(
        doc,
        "Naudotas UCI Steel Industry Energy Consumption rinkinys DOI 10.24432/C52G8C. Jį sudaro "
        "35 040 matavimų, užregistruotų kas 15 minučių. Požymiai apima energijos sąnaudas, reaktyviąją "
        "galią, galios koeficientus, CO2 kiekį, sekundžių skaičių nuo vidurnakčio, savaitės būseną ir apkrovos tipą. "
        "Trūkstamų reikšmių rinkinyje nėra."
    )
    add_figure(doc, FIGURES / "energijos_laiko_eilute.png", "1 pav Energijos suvartojimo laiko eilutė", 6.75)
    add_body(
        doc,
        "Straipsnyje teigiama, kad 15 minučių matavimai agreguoti į vienos valandos intervalus, tačiau kartu "
        "nurodyti tik 4 380 metų įrašai. Vieneri metai turi 8 760 valandų, todėl šie teiginiai nesuderinami. "
        "Atkūrime parinktas dviejų valandų vidurkis, nes jis tiksliai pateikia straipsnyje nurodytus 4 380 įrašų. "
        "Sausio-spalio duomenys, 3 648 įrašai, naudoti mokymui, o lapkričio-gruodžio duomenys, 732 įrašai, testavimui. "
        "Skirstymas atliktas chronologiškai, todėl būsimi duomenys nepateko į mokymo imtį."
    )

    add_heading(doc, "3 Eksperimento metodika")
    add_body(
        doc,
        "Skaitiniai požymiai normalizuoti MinMaxScaler metodu, parametrus apskaičiuojant tik iš mokymo dalies. "
        "Laiko eilutės sekos sudarytos slankiojo lango metodu. Išbandyti 1, 4, 8, 12 ir 16 stebėjimų langai. "
        "Kiekvienas modelis prognozavo kitą energijos suvartojimo reikšmę."
    )
    add_bullet(doc, "Vieno sluoksnio LSTM su 64 atminties vienetais ir 0,1 išmetimo koeficientu")
    add_bullet(doc, "Dviejų sluoksnių LSTM su dviem 64 vienetų sluoksniais ir 0,1 išmetimo koeficientu")
    add_bullet(doc, "Dvikryptis LSTM su 64 vienetais ir 0,1 išmetimo koeficientu")
    add_body(
        doc,
        "Modeliai mokyti 50 epochų, 32 pavyzdžių paketais, Adam optimizatoriumi ir MSE nuostolio funkcija. "
        "Duomenų tvarka mokymo metu nemaišyta. Vertinimui naudoti RMSE, MAE, R2 ir Willmott suderinamumo "
        "indeksas WIA. Kontroliniam palyginimui apskaičiuota pastovumo prognozė, pagal kurią kita reikšmė "
        "lygi paskutinei stebėtai reikšmei."
    )

    add_heading(doc, "4 Programinė ir aparatinė aplinka")
    env_table = doc.add_table(rows=1, cols=2)
    env_table.rows[0].cells[0].text = "Komponentas"
    env_table.rows[0].cells[1].text = "Naudota aplinka"
    env_rows = [
        ("Operacinė sistema", "Microsoft Windows 10 Pro"),
        ("Procesorius", "Intel Core i7-7700K 4,20 GHz"),
        ("Atmintis", "32 GB RAM"),
        ("Python", summary["software"]["python"]),
        ("TensorFlow", summary["software"]["tensorflow"]),
        ("Keras", summary["software"]["keras"]),
        ("Scikit-learn", summary["software"]["scikit_learn"]),
        ("SHAP", summary["software"]["shap"]),
    ]
    for left, right in env_rows:
        cells = env_table.add_row().cells
        cells[0].text = left
        cells[1].text = str(right)
    style_table(env_table)
    add_caption(doc, "1 lentelė Eksperimento aplinka")
    add_body(
        doc,
        "Eksperimentai atlikti lokaliai procesoriumi. Programą sudaro nuoseklūs duomenų paruošimo, modelių "
        "mokymo, vertinimo, grafikų kūrimo ir SHAP analizės etapai. AI agentas naudotas straipsnio analizei, "
        "kodo parengimui, vykdymui, klaidų tikrinimui ir ataskaitos sudarymui. Visi teiginiai apie rezultatus "
        "patikrinti pagal išsaugotus CSV ir JSON failus."
    )

    doc.add_page_break()
    add_heading(doc, "5 Eksperimentų rezultatai")
    add_figure(doc, FIGURES / "langu_ir_architekturu_palyginimas.png", "2 pav LSTM architektūrų ir langų palyginimas", 6.25)
    add_body(
        doc,
        "Visų trijų architektūrų paklaida ryškiai sumažėjo langą padidinus nuo 1 iki 4 stebėjimų. Toliau "
        "rezultatai gerėjo lėčiau. Šiame atkūrime mažiausias RMSE gautas su vieno sluoksnio LSTM ir 12 "
        "stebėjimų langu. Didesnis 16 stebėjimų langas papildomos naudos nesuteikė."
    )

    best_by_arch = (
        all_results[all_results["architecture"].isin(["single_lstm", "double_lstm", "bidirectional_lstm"])]
        .sort_values("rmse_scaled")
        .groupby("architecture", as_index=False)
        .first()
    )
    names = {
        "single_lstm": "Vieno sluoksnio LSTM",
        "double_lstm": "Dviejų sluoksnių LSTM",
        "bidirectional_lstm": "Bi-LSTM",
    }
    table = doc.add_table(rows=1, cols=7)
    headers = ["Modelis", "Langas", "RMSE", "MAE", "R2", "WIA", "Mokymo s"]
    for cell, text in zip(table.rows[0].cells, headers):
        cell.text = text
    for _, row in best_by_arch.iterrows():
        cells = table.add_row().cells
        values = [
            names[row["architecture"]],
            str(int(row["window"])),
            pct(row["rmse_scaled"]),
            pct(row["mae_scaled"]),
            pct(row["r2_scaled"]),
            pct(row["wia_scaled"]),
            f"{row['training_seconds']:.1f}".replace(".", ","),
        ]
        for cell, value in zip(cells, values):
            cell.text = value
    style_table(table, numeric_cols={1, 2, 3, 4, 5, 6})
    add_caption(doc, "2 lentelė Geriausi kiekvienos architektūros rezultatai")

    add_heading(doc, "5 1 Geriausio modelio analizė", level=2)
    add_figure(doc, FIGURES / "tikros_ir_prognozuotos_reiksmes.png", "3 pav Tikros ir prognozuotos testavimo reikšmės", 6.55)
    add_body(
        doc,
        f"Geriausio modelio RMSE pradiniais vienetais buvo {best['rmse_kwh']:.2f} kWh, o MAE "
        f"{best['mae_kwh']:.2f} kWh. R2 reikšmė {pct(best['r2_kwh'])} rodo, kad modelis paaiškino "
        "didelę testavimo laikotarpio energijos suvartojimo sklaidos dalį. Grafike matyti, kad modelis gerai "
        "atkuria darbo ir mažos apkrovos ciklus, tačiau dalį aukščiausių šuolių nuvertina."
    )
    add_figure(doc, FIGURES / "mokymo_eiga.png", "4 pav Geriausio modelio mokymo ir validavimo nuostoliai", 5.7)
    add_body(
        doc,
        "Mokymo ir validavimo nuostoliai mažėjo viso mokymo metu. Validavimo kreivė išliko žemiau mokymo "
        "kreivės, nes mokymo metu taikytas 0,1 išmetimas didino mokymo užduoties sudėtingumą. Ryškaus "
        "persimokymo požymių nepastebėta."
    )

    doc.add_page_break()
    add_heading(doc, "5 2 Palyginimas su straipsniu", level=2)
    selected = comparison[comparison["window"].isin([1, 12, 16])].copy()
    table2 = doc.add_table(rows=1, cols=5)
    for cell, text in zip(table2.rows[0].cells, ["Modelis", "Langas", "Straipsnio RMSE", "Atkartotas RMSE", "Skirtumas"]):
        cell.text = text
    for _, row in selected.iterrows():
        cells = table2.add_row().cells
        values = [
            names[row["architecture"]],
            str(int(row["window"])),
            pct(row["article_rmse"]),
            pct(row["reproduced_rmse"]),
            f"{row['difference']:+.4f}".replace(".", ","),
        ]
        for cell, value in zip(cells, values):
            cell.text = value
    style_table(table2, numeric_cols={1, 2, 3, 4})
    add_caption(doc, "3 lentelė Pasirinktų rezultatų palyginimas su straipsniu")
    add_body(
        doc,
        "Atkurtos RMSE reikšmės yra tokios pačios eilės kaip straipsnyje. Tiksliausiai sutapo vieno "
        "sluoksnio LSTM su vienu stebėjimu: straipsnyje 0,13, atkūrime 0,1299. Geriausias atkūrimo "
        "rezultatas 0,0847 buvo šiek tiek blogesnis už straipsnyje nurodytą 0,08, tačiau aiškiai geresnis "
        "už bazinės prognozės RMSE 0,1878 su tokiu pačiu 12 stebėjimų langu."
    )

    doc.add_page_break()
    add_heading(doc, "6 Paaiškinamojo dirbtinio intelekto analizė")
    add_figure(doc, FIGURES / "shap_pozymiu_svarba.png", "5 pav Vidutinė absoliuti SHAP požymių svarba", 6.0)
    add_body(
        doc,
        "SHAP analizėje didžiausią įtaką turėjo apkrovos tipas, ankstesnis energijos suvartojimas ir savaitės "
        "būsena. Toliau sekė CO2, sekundžių nuo vidurnakčio požymis ir reaktyvioji galia. Straipsnyje ypač "
        "pabrėžta priekinė reaktyvioji galia ir paros laikas. Skirtumą galėjo lemti nepakankamai tiksliai "
        "aprašytas agregavimas, kitokia SHAP imtis, atsitiktinė modelio inicializacija ir skirtingos "
        "programinių bibliotekų versijos."
    )

    add_heading(doc, "7 Rezultatų atkūrimo įvertinimas")
    add_body(
        doc,
        "Pagrindinę straipsnio išvadą pavyko atkartoti: kelių ankstesnių stebėjimų seka prognozuoja geriau "
        "nei vienas stebėjimas, o sudėtingesnė architektūra nebūtinai duoda proporcingą tikslumo pagerėjimą. "
        "Visi 15 straipsnyje nurodytų architektūros ir lango derinių buvo apmokyti ir įvertinti. Rezultatų "
        "failai, modeliai ir grafikai išsaugoti kartu su programa."
    )
    add_body(
        doc,
        "Visiškai tikslaus sutapimo negalima tikėtis, nes straipsnyje nepateiktas programinis kodas, "
        "atsitiktiniai pradžios skaičiai, paketų dydis, Adam mokymosi greitis ir tikslūs kiekvieno stulpelio "
        "agregavimo veiksmai. Svarbiausias neatitikimas yra nurodyti 4 380 vienos valandos įrašų. Šiame "
        "darbe sprendimas aiškiai užfiksuotas: naudotas dviejų valandų vidurkis, nes jis atkuria paskelbtą "
        "imties dydį."
    )

    add_heading(doc, "8 Išvados")
    conclusions = [
        f"Geriausias atkurtas modelis buvo vieno sluoksnio LSTM su 12 stebėjimų langu ir RMSE {pct(best['rmse_scaled'])}.",
        "LSTM modelis daugiau nei perpus sumažino RMSE, palyginti su pastovumo bazine prognoze.",
        "Atkurtos reikšmės buvo artimos straipsnio rezultatams, nors geriausia architektūra nesutapo.",
        "SHAP analizė parodė, kad svarbiausi buvo apkrovos tipas, ankstesnis energijos suvartojimas ir savaitės būsena.",
        "Straipsnio įrašų skaičiaus ir nurodyto valandinio intervalo neatitikimas riboja visiškai tikslų atkūrimą.",
    ]
    for item in conclusions:
        add_bullet(doc, item)

    add_heading(doc, "Literatūra")
    refs = [
        "Maarif M R, Saleh A R, Habibi M, Fitriyani N L, Syafrudin M. Energy Usage Forecasting Model Based on Long Short Term Memory LSTM and eXplainable Artificial Intelligence XAI. Information 14 5 265. DOI 10.3390/info14050265.",
        "Sathishkumar V E, Shin C, Cho Y. Steel Industry Energy Consumption. UCI Machine Learning Repository. DOI 10.24432/C52G8C.",
        "Lundberg S M, Lee S I. A Unified Approach to Interpreting Model Predictions. Advances in Neural Information Processing Systems 30.",
    ]
    for ref in refs:
        p = doc.add_paragraph(ref)
        p.paragraph_format.left_indent = Cm(0.7)
        p.paragraph_format.first_line_indent = Cm(-0.7)

    # Page numbers
    footer = section.footer
    footer_p = footer.paragraphs[0]
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer_p.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr, fld_char2])

    OUT.parent.mkdir(exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    build_report()
