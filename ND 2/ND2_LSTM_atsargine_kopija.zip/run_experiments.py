"""ND2: energy-use forecasting experiment reproduction.

Reproduces the main experiment grid from Maarif et al. (2023):
single-layer, double-layer, and bidirectional LSTM models with sliding windows
of 1, 4, 8, 12, and 16 observations. The UCI steel-industry dataset is
aggregated to two-hour observations because that produces the 4,380 records
reported by the article; the article text calls those records hourly, which is
documented as a reproducibility discrepancy.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import random
import time
from pathlib import Path

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
import sklearn
import tensorflow as tf
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from tensorflow import keras
from tensorflow.keras import layers


ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "Steel_industry_data.csv"
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
MODELS = RESULTS / "models"

FEATURES = [
    "Usage_kWh",
    "Lagging_Current_Reactive.Power_kVarh",
    "Leading_Current_Reactive_Power_kVarh",
    "CO2(tCO2)",
    "Lagging_Current_Power_Factor",
    "Leading_Current_Power_Factor",
    "NSM",
    "WeekStatus",
    "Load_Type",
]
TARGET = "Usage_kWh"
WINDOWS = [1, 4, 8, 12, 16]
ARCHITECTURES = ["single_lstm", "double_lstm", "bidirectional_lstm"]


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    tf.keras.utils.set_random_seed(seed)
    try:
        tf.config.experimental.enable_op_determinism()
    except Exception:
        pass


def load_and_prepare_data() -> pd.DataFrame:
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")

    raw = pd.read_csv(DATA_PATH)
    raw["date"] = pd.to_datetime(raw["date"], dayfirst=True)
    raw = raw.sort_values("date").set_index("date")
    raw["WeekStatus"] = raw["WeekStatus"].map({"Weekend": 0, "Weekday": 1})
    raw["Load_Type"] = raw["Load_Type"].map(
        {"Light_Load": 1, "Medium_Load": 2, "Maximum_Load": 3}
    )

    numeric = raw[FEATURES].apply(pd.to_numeric)
    # Two-hour means yield exactly 4,380 observations, matching the article's
    # reported sample count. A true one-hour aggregation would yield 8,760.
    hourly_like = numeric.resample("2h").mean()
    if len(hourly_like) != 4380 or hourly_like.isna().any().any():
        raise ValueError("Unexpected aggregation result")
    return hourly_like


def split_and_scale(data: pd.DataFrame):
    # January-October for training, November-December for testing, as reported.
    train = data.loc[data.index.month <= 10].copy()
    test = data.loc[data.index.month > 10].copy()

    x_scaler = MinMaxScaler().fit(train[FEATURES])
    y_scaler = MinMaxScaler().fit(train[[TARGET]])
    train_scaled = x_scaler.transform(train[FEATURES])
    test_scaled = x_scaler.transform(test[FEATURES])
    return train, test, train_scaled, test_scaled, x_scaler, y_scaler


def sequences(values: np.ndarray, window: int, target_index: int = 0):
    x, y = [], []
    for end in range(window, len(values)):
        x.append(values[end - window : end])
        y.append(values[end, target_index])
    return np.asarray(x, dtype=np.float32), np.asarray(y, dtype=np.float32)


def build_model(architecture: str, window: int, feature_count: int) -> keras.Model:
    inputs = keras.Input(shape=(window, feature_count))
    if architecture == "single_lstm":
        x = layers.LSTM(64)(inputs)
        x = layers.Dropout(0.1)(x)
    elif architecture == "double_lstm":
        x = layers.LSTM(64, return_sequences=True)(inputs)
        x = layers.Dropout(0.1)(x)
        x = layers.LSTM(64)(x)
        x = layers.Dropout(0.1)(x)
    elif architecture == "bidirectional_lstm":
        x = layers.Bidirectional(layers.LSTM(64))(inputs)
        x = layers.Dropout(0.1)(x)
    else:
        raise ValueError(f"Unknown architecture: {architecture}")
    outputs = layers.Dense(1)(x)
    model = keras.Model(inputs, outputs, name=architecture)
    model.compile(optimizer=keras.optimizers.Adam(), loss="mse")
    return model


def willmott_index(actual: np.ndarray, predicted: np.ndarray) -> float:
    mean_actual = np.mean(actual)
    numerator = np.sum((predicted - actual) ** 2)
    denominator = np.sum(
        (np.abs(predicted - mean_actual) + np.abs(actual - mean_actual)) ** 2
    )
    return float(1 - numerator / denominator) if denominator else float("nan")


def evaluate(
    actual_scaled: np.ndarray,
    predicted_scaled: np.ndarray,
    y_scaler: MinMaxScaler,
) -> dict[str, float]:
    actual = y_scaler.inverse_transform(actual_scaled.reshape(-1, 1)).ravel()
    predicted = y_scaler.inverse_transform(predicted_scaled.reshape(-1, 1)).ravel()
    return {
        "rmse_scaled": float(np.sqrt(mean_squared_error(actual_scaled, predicted_scaled))),
        "mae_scaled": float(mean_absolute_error(actual_scaled, predicted_scaled)),
        "r2_scaled": float(r2_score(actual_scaled, predicted_scaled)),
        "wia_scaled": willmott_index(actual_scaled, predicted_scaled),
        "rmse_kwh": float(np.sqrt(mean_squared_error(actual, predicted))),
        "mae_kwh": float(mean_absolute_error(actual, predicted)),
        "r2_kwh": float(r2_score(actual, predicted)),
    }


def plot_dataset(data: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(11, 4.2))
    ax.plot(data.index, data[TARGET], color="#245b8a", linewidth=0.75)
    ax.set(title="Plieno gamyklos energijos suvartojimas", ylabel="Energija, kWh", xlabel="Laikas")
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(FIGURES / "energijos_laiko_eilute.png", dpi=180)
    plt.close(fig)


def plot_window_comparison(summary: pd.DataFrame) -> None:
    labels = {
        "single_lstm": "Vieno sluoksnio LSTM",
        "double_lstm": "Dviejų sluoksnių LSTM",
        "bidirectional_lstm": "Bi-LSTM",
    }
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    for architecture in ARCHITECTURES:
        part = summary[summary["architecture"] == architecture].sort_values("window")
        ax.plot(part["window"], part["rmse_scaled"], marker="o", label=labels[architecture])
    ax.set(xlabel="Slankiojo lango dydis", ylabel="Testavimo RMSE (normalizuota)")
    ax.set_xticks(WINDOWS)
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES / "langu_ir_architekturu_palyginimas.png", dpi=180)
    plt.close(fig)


def plot_predictions(index, actual, predicted, architecture: str) -> None:
    labels = {
        "single_lstm": "vieno sluoksnio LSTM",
        "double_lstm": "dviejų sluoksnių LSTM",
        "bidirectional_lstm": "Bi-LSTM",
    }
    n = min(360, len(actual))
    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.plot(index[:n], actual[:n], label="Tikroji reikšmė", color="#202020", linewidth=1.2)
    ax.plot(index[:n], predicted[:n], label="Prognozė", color="#d55e00", linewidth=1.1)
    ax.set(title=f"Geriausio modelio prognozė: {labels.get(architecture, architecture)}", ylabel="Energija, kWh", xlabel="Laikas")
    ax.grid(alpha=0.2)
    ax.legend(frameon=False)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(FIGURES / "tikros_ir_prognozuotos_reiksmes.png", dpi=180)
    plt.close(fig)


def plot_history(history: dict[str, list[float]]) -> None:
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(history["loss"], label="Mokymo nuostolis")
    ax.plot(history["val_loss"], label="Validavimo nuostolis")
    ax.set(xlabel="Epocha", ylabel="MSE", title="Geriausio modelio mokymo eiga")
    ax.grid(alpha=0.25)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES / "mokymo_eiga.png", dpi=180)
    plt.close(fig)


def shap_feature_importance(model, x_train, x_test) -> dict[str, float]:
    rng = np.random.default_rng(42)
    background = x_train[rng.choice(len(x_train), min(80, len(x_train)), replace=False)]
    samples = x_test[rng.choice(len(x_test), min(160, len(x_test)), replace=False)]
    explainer = shap.GradientExplainer(model, background)
    shap_values = explainer.shap_values(samples)
    values = shap_values[0] if isinstance(shap_values, list) else shap_values
    values = np.asarray(values)
    if values.ndim == 4:
        values = values[..., 0]
    importance = np.mean(np.abs(values), axis=(0, 1))
    order = np.argsort(importance)

    fig, ax = plt.subplots(figsize=(8.2, 5.0))
    ax.barh(np.asarray(FEATURES)[order], importance[order], color="#3f78a8")
    ax.set(xlabel="Vidutinė absoliuti SHAP reikšmė", title="Požymių įtaka geriausiam LSTM modeliui")
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout()
    fig.savefig(FIGURES / "shap_pozymiu_svarba.png", dpi=180)
    plt.close(fig)
    return {feature: float(value) for feature, value in zip(FEATURES, importance)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    RESULTS.mkdir(exist_ok=True)
    FIGURES.mkdir(exist_ok=True)
    MODELS.mkdir(exist_ok=True)
    set_seed(args.seed)

    data = load_and_prepare_data()
    train, test, train_scaled, test_scaled, x_scaler, y_scaler = split_and_scale(data)
    joblib.dump(x_scaler, MODELS / "input_scaler.joblib")
    joblib.dump(y_scaler, MODELS / "target_scaler.joblib")
    plot_dataset(data)

    rows: list[dict] = []
    best = None
    best_payload = None

    # Persistence baseline: next value equals the most recent observed usage.
    for window in WINDOWS:
        _, y_test = sequences(test_scaled, window)
        persistence = test_scaled[window - 1 : -1, 0]
        row = {
            "architecture": "persistence_baseline",
            "window": window,
            "seed": args.seed,
            "epochs": 0,
            "training_seconds": 0.0,
            **evaluate(y_test, persistence, y_scaler),
        }
        rows.append(row)

    for architecture in ARCHITECTURES:
        for window in WINDOWS:
            set_seed(args.seed)
            x_train, y_train = sequences(train_scaled, window)
            x_test, y_test = sequences(test_scaled, window)
            validation_count = int(len(x_train) * 0.15)
            x_fit, x_val = x_train[:-validation_count], x_train[-validation_count:]
            y_fit, y_val = y_train[:-validation_count], y_train[-validation_count:]

            model = build_model(architecture, window, len(FEATURES))
            started = time.perf_counter()
            history = model.fit(
                x_fit,
                y_fit,
                validation_data=(x_val, y_val),
                epochs=args.epochs,
                batch_size=args.batch_size,
                shuffle=False,
                verbose=0,
            )
            elapsed = time.perf_counter() - started
            prediction = model.predict(x_test, verbose=0).ravel()
            metrics = evaluate(y_test, prediction, y_scaler)
            row = {
                "architecture": architecture,
                "window": window,
                "seed": args.seed,
                "epochs": args.epochs,
                "training_seconds": elapsed,
                **metrics,
            }
            rows.append(row)
            print(
                f"{architecture:20s} window={window:2d} "
                f"RMSE={metrics['rmse_scaled']:.5f} R2={metrics['r2_scaled']:.4f} "
                f"time={elapsed:.1f}s",
                flush=True,
            )

            if best is None or metrics["rmse_scaled"] < best["rmse_scaled"]:
                best = row.copy()
                best_payload = {
                    "model": model,
                    "history": history.history,
                    "x_train": x_train,
                    "x_test": x_test,
                    "y_test": y_test,
                    "prediction": prediction,
                    "window": window,
                }
            if window == 16:
                model.save(MODELS / f"{architecture}_window16.keras")
            tf.keras.backend.clear_session()

    results = pd.DataFrame(rows)
    results.to_csv(RESULTS / "visi_bandymu_rezultatai.csv", index=False)
    lstm_results = results[results["architecture"].isin(ARCHITECTURES)].copy()
    lstm_results.to_csv(RESULTS / "lstm_rezultatu_santrauka.csv", index=False)
    plot_window_comparison(lstm_results)

    assert best is not None and best_payload is not None
    best_model = best_payload["model"]
    best_model.save(MODELS / "geriausias_modelis.keras")
    actual_kwh = y_scaler.inverse_transform(best_payload["y_test"].reshape(-1, 1)).ravel()
    predicted_kwh = y_scaler.inverse_transform(best_payload["prediction"].reshape(-1, 1)).ravel()
    prediction_index = test.index[best_payload["window"] :]
    pd.DataFrame(
        {
            "date": prediction_index,
            "actual_kwh": actual_kwh,
            "predicted_kwh": predicted_kwh,
            "error_kwh": predicted_kwh - actual_kwh,
        }
    ).to_csv(RESULTS / "geriausio_modelio_prognozes.csv", index=False)
    plot_predictions(prediction_index, actual_kwh, predicted_kwh, best["architecture"])
    plot_history(best_payload["history"])

    shap_error = None
    try:
        shap_importance = shap_feature_importance(
            best_model, best_payload["x_train"], best_payload["x_test"]
        )
    except Exception as exc:
        shap_importance = {}
        shap_error = f"{type(exc).__name__}: {exc}"

    article_rmse = {
        "single_lstm": {1: 0.13, 4: 0.10, 8: 0.09, 12: 0.08, 16: 0.08},
        "double_lstm": {1: 0.11, 4: 0.09, 8: 0.08, 12: 0.08, 16: 0.07},
        "bidirectional_lstm": {1: 0.14, 4: 0.12, 8: 0.10, 12: 0.08, 16: 0.07},
    }
    comparisons = []
    for _, row in lstm_results.iterrows():
        reported = article_rmse[row["architecture"]][int(row["window"])]
        comparisons.append(
            {
                "architecture": row["architecture"],
                "window": int(row["window"]),
                "article_rmse": reported,
                "reproduced_rmse": float(row["rmse_scaled"]),
                "difference": float(row["rmse_scaled"] - reported),
            }
        )
    pd.DataFrame(comparisons).to_csv(RESULTS / "palyginimas_su_straipsniu.csv", index=False)

    summary = {
        "dataset": {
            "raw_rows": 35040,
            "aggregated_rows": len(data),
            "train_rows": len(train),
            "test_rows": len(test),
            "interval": "2h",
            "reason_for_2h": "Matches the article's stated total of 4,380 records; true 1h would yield 8,760.",
        },
        "best_model": best,
        "shap_feature_importance": shap_importance,
        "shap_error": shap_error,
        "software": {
            "python": platform.python_version(),
            "tensorflow": tf.__version__,
            "keras": keras.__version__,
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "scikit_learn": sklearn.__version__,
            "shap": shap.__version__,
            "platform": platform.platform(),
        },
    }
    (RESULTS / "santrauka.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary["best_model"], ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
